def main():
    message = "Hello from the Python script!"
    return message

# If you need to run this script standalone, you can include:
if __name__ == "__main__":
    print(main())